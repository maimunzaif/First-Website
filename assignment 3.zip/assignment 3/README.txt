The index page
It has a header on top with an icon and inside the header tag. 
Following which there is a navigation bar where the �Gallery� and �Be a photographer� tags take you to those html pages. And the rest of the tags take you to those sections with in the index.html.
After that there is an About section which tells about myself and then a projects section which shows the photography project I have undertaken on a cat. 
There are some pictures of the cat in question and the pictures have a hyperlink to a YouTube video that tells more about this breed of cat in case someone is interested about them.
Lastly there is a contact section at the bottom with socials and contact along with anchor tags leading to them.

The Gallery
It has a header on top with an icon and inside the header tag. 
Following which there is a navigation bar where the �Gallery� and �Be a photographer� tags take you to those html pages. 
And the rest of the tags take you to those sections with in the index.html.
And then a table under, inside it with pictures and a video that I have taken.

The �Be a photographer� page
It has a header on top with an icon and inside the header tag. 
Following which there is a navigation bar where the �Gallery� and �Be a photographer� tags take you to those html pages.
And the rest of the tags take you to those sections with in the index.html.
It has an ordered list which includes the things one would need to get into photography. 
Along with a nested unordered list for �lenses� , �Lighting Equipment� and �Photography Software� because there were subdivisions of things that I needed to include among them.

