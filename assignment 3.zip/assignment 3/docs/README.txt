README



The index page includes a header with the website's title and logo, a navigation bar, and a hero Image section with a welcome message and a 'Get Started' button linking to the about page. The navigation bar consists of links to the home page, the about page, the gallery page, the projects section of the about page, the contact section of the about page, and a "Be a photographer" page.

The website can be used in a phone, tablet or a desktop. it has been sized and scaled so that it is usable on all the devices. Like for example, the navigation bar normally spreads acress the page on a destop when when viewed from aphone, it changed into a drop down menu so that all the tabs can be seen clearly.

The about page includes the same header and navigation bar as the index page. Additionally, the about page contains a card with color options and three sections: an about section that includes a brief biography of the website owner and their future plans, a projects section that includes information about the website owner's past projects and a photo gallery, and a contact section that includes the website owner's email address and phone number. 

the learn page includes a list of items you would need to start a photography and an iframe video of a tutorial. The gallery page has a table where the more pictures from the photgrapher are listed. And ALL the photoes in this website belong to its author Zaif Tanay as he's the photographer and owner for all these photos.