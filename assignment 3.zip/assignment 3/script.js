window.addEventListener("load", () => {
    const colorItems = document.querySelectorAll('.color-item');
    colorItems.forEach( item => {
        item.addEventListener('click', function() {
            const idSelected = this.id;
            document.body.className = idSelected;
        })
    })
})

const links = document.querySelectorAll("a");
links.forEach(link => {
  link.addEventListener("click", function(event) {
    if (this.hostname !== window.location.hostname) {
      event.preventDefault();
      window.open(this.href);
      alert("You are leaving our website and visiting " + this.hostname);
    }
  });
});
